# Dragon Whitelist Service — Self-hosted Luarmor Clone

Full whitelist system: obfuscation, HWID locking, time keys, Discord bot with control panel.

## Files
- `server.js`        — Express API (Railway)
- `bot.js`           — Discord.js bot
- `dashboard/`       — Web dashboard
- `supabase_schema.sql` — DB tables
- `lua/loader.lua`   — What users execute
- `.env.example`     — Config template

## Deploy in 15 minutes

### 1. Supabase
1. Create project at supabase.com
2. Run `supabase_schema.sql` in the SQL editor
3. Get your **Project URL** and **Service Role key** from Settings > API

### 2. Discord Bot
1. Go to discord.com/developers → New Application
2. Bot tab → Reset Token → copy it
3. OAuth2 → URL Generator → scopes: `bot`, `applications.commands`
4. Bot permissions: `Manage Roles`, `Send Messages`, `Embed Links`, `Attach Files`
5. Invite bot to your server

### 3. Railway
1. `npm install`
2. `railway init && railway up`
3. Add environment variables in Railway dashboard:

```
SUPABASE_URL=https://xxx.supabase.co
SUPABASE_SERVICE_KEY=your-service-role-key
DISCORD_BOT_TOKEN=your-bot-token
DISCORD_CLIENT_ID=your-app-client-id
MASTER_SECRET=any-long-random-string-32chars+
ADMIN_SECRET=another-secret-for-creating-owners
PORT=3000
```

### 4. Create your owner account
POST to `https://your-app.up.railway.app/v1/admin/owners`:
```json
{
  "admin_secret": "your-ADMIN_SECRET",
  "email": "you@email.com",
  "plan": "elite"
}
```
Save the `api_key` from the response — this is your dashboard login.

### 5. Dashboard
Visit `https://your-app.up.railway.app` and log in with your API key.

### 6. Discord Setup
In your Discord server:
```
/login api_key: YOUR_API_KEY
/setup project_id: PROJECT_ID buyer_role: @Buyers manager_role: @Mods
/panel   ← posts the control panel in the current channel
```

### 7. Upload a script
Dashboard → Projects → Upload Script → paste your Lua → Obfuscate & Upload

## Bot Commands

| Command | Role | What it does |
|---------|------|-------------|
| `/login` | Admin | Link server to your account |
| `/setup` | Admin | Set project, buyer role, manager role |
| `/panel` | Manager | Post the control panel embed with buttons |
| `/whitelist @user [days]` | Manager | Give a user a key |
| `/revoke @user` | Manager | Revoke key + remove buyer role |
| `/resethwid @user` | Manager | Clear HWID lock |
| `/extend @user [days]` | Manager | Add days to expiry |
| `/keyinfo @user` | Manager | Full key details |
| `/genkeys [amount] [days]` | Manager | Bulk generate unused keys |
| `/listkeys [page]` | Manager | List all keys |
| `/stats` | Manager | Server stats |
| `/announce [message]` | Manager | DM all active users |
| **Redeem Key** button | User | Claim a key via modal popup |
| **Get Script** button | User | Get loader DM'd |
| **Get Role** button | User | Get buyer role |
| **Reset HWID** button | User | Self-service HWID reset |
| **Get Stats** button | User | View own key info |

## Obfuscation Levels
Upload with `"level": "full"` (default) or `"level": "light"` in the API body.

Full pipeline:
1. Variable renaming → random hex names
2. String encoding → byte arrays via string.char
3. Number encoding → bit32.bxor expressions
4. Junk insertion → dead code every ~12 lines
5. XOR+Base64 wrapper → full source encrypted, decodes at runtime

For maximum protection: use the output as input to luaobfuscator.com (Luraph VM layer on top).
