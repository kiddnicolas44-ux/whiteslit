require("dotenv").config();
const {
    Client, GatewayIntentBits, SlashCommandBuilder, REST, Routes,
    EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle,
    ModalBuilder, TextInputBuilder, TextInputStyle,
    PermissionFlagsBits, StringSelectMenuBuilder, ActivityType
} = require("discord.js");
const { createClient } = require("@supabase/supabase-js");
const crypto = require("crypto");

const sb      = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY);
const SECRET  = process.env.MASTER_SECRET;
const BASE    = process.env.RAILWAY_PUBLIC_DOMAIN
    ? `https://${process.env.RAILWAY_PUBLIC_DOMAIN}`
    : `http://localhost:${process.env.PORT || 3000}`;

// ── Colors ────────────────────────────────────────────────────────────────────
const COL = {
    main:   0x7c3aed,  // purple
    ok:     0x22c55e,  // green
    err:    0xef4444,  // red
    warn:   0xf59e0b,  // amber
    info:   0x3b82f6,  // blue
    dark:   0x0f0d16,  // dark bg
};

// ── Internal API helpers ──────────────────────────────────────────────────────
async function internalPost(path, body) {
    const r = await fetch(`${BASE}${path}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ secret: SECRET, ...body })
    });
    return r.json();
}
async function internalGet(path, params = {}) {
    const qs = new URLSearchParams({ secret: SECRET, ...params }).toString();
    const r  = await fetch(`${BASE}${path}?${qs}`);
    return r.json();
}
async function ownerApi(method, path, apiKey, body) {
    const r = await fetch(`${BASE}${path}`, {
        method,
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${apiKey}` },
        body: body ? JSON.stringify(body) : undefined
    });
    return r.json();
}

// ── Guild config ──────────────────────────────────────────────────────────────
async function getCfg(guildId) {
    const { data } = await sb.from("bot_configs").select("*").eq("guild_id", guildId).single();
    return data;
}
async function setCfg(guildId, updates) {
    const { data } = await sb.from("bot_configs")
        .upsert({ guild_id: guildId, ...updates, updated_at: new Date().toISOString() }, { onConflict: "guild_id" })
        .select().single();
    return data;
}

// ── Time helpers ──────────────────────────────────────────────────────────────
function formatExpiry(k) {
    if (!k.expires_at) return "♾️ Lifetime";
    const sec = k.expires_at - Math.floor(Date.now() / 1000);
    if (sec <= 0) return "⛔ Expired";
    const d = Math.floor(sec / 86400);
    const h = Math.floor((sec % 86400) / 3600);
    if (d > 0) return `⏳ ${d}d ${h}h`;
    return `⏳ ${h}h ${Math.floor((sec % 3600) / 60)}m`;
}

function isManager(member, cfg) {
    if (!member) return false;
    if (member.permissions.has(PermissionFlagsBits.Administrator)) return true;
    if (cfg?.manager_role_id && member.roles.cache.has(cfg.manager_role_id)) return true;
    return false;
}

// ── CONTROL PANEL EMBED ───────────────────────────────────────────────────────
function buildPanel(cfg, projectName) {
    const embed = new EmbedBuilder()
        .setColor(COL.main)
        .setAuthor({
            name: projectName || "Script Hub",
            iconURL: "https://cdn.discordapp.com/embed/avatars/0.png"
        })
        .setTitle(`${projectName || "Script"} Control Panel`)
        .setDescription(
            `This control panel is for the project: **${projectName || "Script"}**\n` +
            `If you're a buyer, click on the buttons below to redeem your key, get the script or get your role.`
        )
        .setFooter({ text: `Dragon Whitelist • ${new Date().toLocaleString("en-US", { month: "short", day: "numeric", year: "numeric", hour: "2-digit", minute: "2-digit" })}` })
        .setTimestamp();

    const row1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("panel_redeem").setLabel("Redeem Key").setEmoji("🔑").setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId("panel_script").setLabel("Get Script").setEmoji("📋").setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId("panel_role").setLabel("Get Role").setEmoji("🎭").setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId("panel_hwid").setLabel("Reset HWID").setEmoji("⚙️").setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId("panel_stats").setLabel("Get Stats").setEmoji("📊").setStyle(ButtonStyle.Secondary),
    );

    return { embeds: [embed], components: [row1] };
}

// ── CLIENT ────────────────────────────────────────────────────────────────────
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.DirectMessages
    ]
});

// ── SLASH COMMANDS ────────────────────────────────────────────────────────────
const commands = [
    new SlashCommandBuilder()
        .setName("login").setDescription("Link this server to your Dragon Whitelist account")
        .addStringOption(o => o.setName("api_key").setDescription("Your API key from the dashboard").setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    new SlashCommandBuilder()
        .setName("setup").setDescription("Configure project, roles and channels for this server")
        .addStringOption(o => o.setName("project_id").setDescription("Your project ID").setRequired(true))
        .addRoleOption(o => o.setName("buyer_role").setDescription("Role given to buyers").setRequired(true))
        .addRoleOption(o => o.setName("manager_role").setDescription("Role that can run management commands").setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    new SlashCommandBuilder()
        .setName("panel").setDescription("Post the user control panel in this channel")
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

    new SlashCommandBuilder()
        .setName("whitelist").setDescription("Whitelist a user and generate their key")
        .addUserOption(o => o.setName("user").setDescription("User to whitelist").setRequired(true))
        .addIntegerOption(o => o.setName("days").setDescription("Days until expiry (empty = lifetime)"))
        .addStringOption(o => o.setName("note").setDescription("Custom note for this key")),

    new SlashCommandBuilder()
        .setName("revoke").setDescription("Revoke a user's key and remove their role")
        .addUserOption(o => o.setName("user").setDescription("User to revoke").setRequired(true)),

    new SlashCommandBuilder()
        .setName("resethwid").setDescription("Reset a user's HWID lock")
        .addUserOption(o => o.setName("user").setDescription("User to reset").setRequired(true)),

    new SlashCommandBuilder()
        .setName("extend").setDescription("Add days to a user's key")
        .addUserOption(o => o.setName("user").setDescription("User to extend").setRequired(true))
        .addIntegerOption(o => o.setName("days").setDescription("Days to add").setRequired(true)),

    new SlashCommandBuilder()
        .setName("keyinfo").setDescription("View a user's key details")
        .addUserOption(o => o.setName("user").setDescription("User to look up").setRequired(true)),

    new SlashCommandBuilder()
        .setName("genkeys").setDescription("Generate unused keys (for selling on Sellix/Shoppy)")
        .addIntegerOption(o => o.setName("amount").setDescription("How many keys (max 500)").setRequired(true))
        .addIntegerOption(o => o.setName("days").setDescription("Days until expiry (empty = lifetime)"))
        .addStringOption(o => o.setName("note").setDescription("Note for this batch")),

    new SlashCommandBuilder()
        .setName("listkeys").setDescription("List all keys for a project")
        .addIntegerOption(o => o.setName("page").setDescription("Page number (default 1)")),

    new SlashCommandBuilder()
        .setName("stats").setDescription("View server statistics")
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    new SlashCommandBuilder()
        .setName("announce").setDescription("Announce a script update to all whitelisted users")
        .addStringOption(o => o.setName("message").setDescription("The announcement message").setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
];

async function registerCommands() {
    const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_BOT_TOKEN);
    await rest.put(Routes.applicationCommands(process.env.DISCORD_CLIENT_ID), { body: commands.map(c => c.toJSON()) });
    console.log("[Bot] Slash commands registered globally");
}

// ── INTERACTION HANDLER ───────────────────────────────────────────────────────
client.on("interactionCreate", async interaction => {
    try {
        if (interaction.isChatInputCommand()) return handleCommand(interaction);
        if (interaction.isButton())            return handleButton(interaction);
        if (interaction.isModalSubmit())        return handleModal(interaction);
    } catch (err) {
        console.error("[Bot] Interaction error:", err);
    }
});

// ─────────────────────────────────────────────────────────────────────────────
// SLASH COMMAND HANDLER
// ─────────────────────────────────────────────────────────────────────────────
async function handleCommand(interaction) {
    const { commandName, guildId } = interaction;
    await interaction.deferReply({ ephemeral: true });

    const cfg    = await getCfg(guildId);
    const member = interaction.member;

    // ── /login ────────────────────────────────────────────────────────────────
    if (commandName === "login") {
        if (!member.permissions.has(PermissionFlagsBits.Administrator))
            return reply(interaction, "❌ Admins only", COL.err);
        const apiKey = interaction.options.getString("api_key");
        const data   = await ownerApi("GET", "/v1/account", apiKey);
        if (!data.success) return reply(interaction, "❌ Invalid API key — check your dashboard", COL.err);
        await setCfg(guildId, { api_key: apiKey, email: data.account.email, plan: data.account.plan });
        return replyEmbed(interaction, new EmbedBuilder()
            .setColor(COL.ok).setTitle("✅ Server Linked!")
            .addFields(
                { name: "Account", value: data.account.email, inline: true },
                { name: "Plan", value: `\`${data.account.plan}\``, inline: true }
            ).setDescription("Run `/setup` next to configure project + roles."));
    }

    if (!cfg?.api_key && commandName !== "login")
        return reply(interaction, "❌ Run `/login <api_key>` first to set up this server", COL.err);

    // ── /setup ────────────────────────────────────────────────────────────────
    if (commandName === "setup") {
        if (!member.permissions.has(PermissionFlagsBits.Administrator))
            return reply(interaction, "❌ Admins only", COL.err);
        const projectId    = interaction.options.getString("project_id");
        const buyerRole    = interaction.options.getRole("buyer_role");
        const managerRole  = interaction.options.getRole("manager_role");
        // Verify project exists
        const data = await ownerApi("GET", `/v1/projects`, cfg.api_key);
        const proj = data.projects?.find(p => p.id === projectId);
        if (!proj) return reply(interaction, "❌ Project not found — check the ID in your dashboard", COL.err);
        await setCfg(guildId, {
            project_id:      projectId,
            project_name:    proj.name,
            buyer_role_id:   buyerRole.id,
            manager_role_id: managerRole?.id || null,
        });
        return replyEmbed(interaction, new EmbedBuilder()
            .setColor(COL.ok).setTitle("✅ Setup Complete")
            .addFields(
                { name: "Project", value: proj.name, inline: true },
                { name: "Buyer Role", value: `<@&${buyerRole.id}>`, inline: true },
                { name: "Manager Role", value: managerRole ? `<@&${managerRole.id}>` : "Not set", inline: true }
            ).setDescription("Post a control panel with `/panel`"));
    }

    // ── /panel ────────────────────────────────────────────────────────────────
    if (commandName === "panel") {
        if (!isManager(member, cfg)) return reply(interaction, "❌ No permission", COL.err);
        const panel = buildPanel(cfg, cfg.project_name || "Script Hub");
        await interaction.channel.send(panel);
        return reply(interaction, "✅ Control panel posted!", COL.ok);
    }

    // ── /whitelist ────────────────────────────────────────────────────────────
    if (commandName === "whitelist") {
        if (!isManager(member, cfg)) return reply(interaction, "❌ No permission", COL.err);
        const target = interaction.options.getUser("user");
        const days   = interaction.options.getInteger("days") || null;
        const note   = interaction.options.getString("note") || null;
        const result = await internalPost("/internal/whitelist", {
            project_id: cfg.project_id, discord_id: target.id, days, note
        });
        if (!result.success) return reply(interaction, `❌ ${result.error}`, COL.err);
        // Give buyer role
        try {
            const gm = await interaction.guild.members.fetch(target.id);
            if (cfg.buyer_role_id) await gm.roles.add(cfg.buyer_role_id);
        } catch {}
        // DM user their key
        try {
            await target.send({ embeds: [new EmbedBuilder()
                .setColor(COL.ok).setTitle("🔑 You've Been Whitelisted!")
                .setDescription(`Your key for **${cfg.project_name || "the script"}**:`)
                .addFields(
                    { name: "Key", value: `\`\`\`${result.key}\`\`\``, inline: false },
                    { name: "Expires", value: days ? `${days} days from first run` : "♾️ Lifetime", inline: true },
                    { name: "Usage", value: `Put \`script_key = "${result.key}";\` above the loader`, inline: false }
                ).setFooter({ text: "Do not share your key — HWID locks on first run" })]
            });
        } catch {}
        return replyEmbed(interaction, new EmbedBuilder()
            .setColor(COL.ok).setTitle("✅ Whitelisted")
            .setDescription(`<@${target.id}> has been whitelisted and DM'd their key.`)
            .addFields(
                { name: "Key", value: `\`${result.key}\``, inline: false },
                { name: "Expires", value: days ? `${days} days` : "Lifetime", inline: true },
                { name: "Note", value: note || "None", inline: true }
            ));
    }

    // ── /revoke ───────────────────────────────────────────────────────────────
    if (commandName === "revoke") {
        if (!isManager(member, cfg)) return reply(interaction, "❌ No permission", COL.err);
        const target = interaction.options.getUser("user");
        await internalPost("/internal/revoke", { discord_id: target.id });
        try {
            const gm = await interaction.guild.members.fetch(target.id);
            if (cfg.buyer_role_id) await gm.roles.remove(cfg.buyer_role_id).catch(() => {});
        } catch {}
        try { await target.send({ embeds: [new EmbedBuilder().setColor(COL.err)
            .setTitle("🚫 Access Revoked").setDescription("Your whitelist access has been revoked. Contact support if this is an error.")] }); } catch {}
        return reply(interaction, `✅ Revoked access for <@${target.id}>`, COL.ok);
    }

    // ── /resethwid ────────────────────────────────────────────────────────────
    if (commandName === "resethwid") {
        if (!isManager(member, cfg)) return reply(interaction, "❌ No permission", COL.err);
        const target = interaction.options.getUser("user");
        const result = await internalPost("/internal/resethwid", { discord_id: target.id });
        if (!result.success) return reply(interaction, `❌ ${result.error}`, COL.err);
        try { await target.send({ embeds: [new EmbedBuilder().setColor(COL.info)
            .setTitle("🔓 HWID Reset").setDescription("Your HWID has been reset. Your new HWID will lock on your next script run.")] }); } catch {}
        return reply(interaction, `✅ HWID reset for <@${target.id}>`, COL.ok);
    }

    // ── /extend ───────────────────────────────────────────────────────────────
    if (commandName === "extend") {
        if (!isManager(member, cfg)) return reply(interaction, "❌ No permission", COL.err);
        const target = interaction.options.getUser("user");
        const days   = interaction.options.getInteger("days");
        const info   = await internalGet("/internal/keyinfo", { discord_id: target.id });
        if (!info.keys?.length) return reply(interaction, "❌ No key found for this user", COL.err);
        const k = info.keys[0];
        const data = await ownerApi("POST", `/v1/keys/${k.key_string}/extend`, cfg.api_key, { days });
        if (!data.success) return reply(interaction, `❌ ${data.error}`, COL.err);
        const newDate = new Date(data.new_expiry * 1000).toLocaleDateString();
        try { await target.send({ embeds: [new EmbedBuilder().setColor(COL.ok)
            .setTitle("✅ Key Extended").setDescription(`Your key has been extended by **${days} day${days !== 1 ? "s" : ""}**.\nNew expiry: **${newDate}**`)] }); } catch {}
        return reply(interaction, `✅ Extended <@${target.id}>'s key by ${days} days. New expiry: ${newDate}`, COL.ok);
    }

    // ── /keyinfo ──────────────────────────────────────────────────────────────
    if (commandName === "keyinfo") {
        if (!isManager(member, cfg)) return reply(interaction, "❌ No permission", COL.err);
        const target = interaction.options.getUser("user");
        const result = await internalGet("/internal/keyinfo", { discord_id: target.id });
        if (!result.keys?.length) return reply(interaction, "❌ No key found for this user", COL.err);
        const k = result.keys[0];
        return replyEmbed(interaction, new EmbedBuilder()
            .setColor(k.active ? COL.main : COL.err)
            .setTitle(`🔑 Key Info — ${target.username}`)
            .setThumbnail(target.displayAvatarURL())
            .addFields(
                { name: "Key",        value: `\`${k.key_string}\``,                           inline: false },
                { name: "Status",     value: k.active ? "✅ Active" : "❌ Revoked",            inline: true },
                { name: "Expires",    value: formatExpiry(k),                                  inline: true },
                { name: "HWID",       value: k.hwid ? "🔒 Locked" : "🔓 Unlocked",            inline: true },
                { name: "Total Runs", value: `${k.total_executions || 0}`,                     inline: true },
                { name: "Last Run",   value: k.last_exec ? `<t:${Math.floor(new Date(k.last_exec).getTime()/1000)}:R>` : "Never", inline: true },
                { name: "Note",       value: k.note || "None",                                 inline: true }
            ).setTimestamp());
    }

    // ── /genkeys ──────────────────────────────────────────────────────────────
    if (commandName === "genkeys") {
        if (!isManager(member, cfg)) return reply(interaction, "❌ No permission", COL.err);
        const amount = Math.min(interaction.options.getInteger("amount"), 500);
        const days   = interaction.options.getInteger("days") || null;
        const note   = interaction.options.getString("note") || null;
        const result = await ownerApi("POST", `/v1/projects/${cfg.project_id}/keys`, cfg.api_key, {
            amount, key_days: days, note
        });
        if (!result.success) return reply(interaction, `❌ ${result.error}`, COL.err);
        const txt = result.keys.join("\n");
        return interaction.editReply({
            embeds: [new EmbedBuilder().setColor(COL.ok)
                .setTitle("🗝️ Keys Generated")
                .setDescription(`Generated **${result.count}** keys — ${days ? `${days} day expiry` : "Lifetime"}`)],
            files: [{ attachment: Buffer.from(txt), name: `keys_${Date.now()}.txt` }]
        });
    }

    // ── /listkeys ─────────────────────────────────────────────────────────────
    if (commandName === "listkeys") {
        if (!isManager(member, cfg)) return reply(interaction, "❌ No permission", COL.err);
        const page = interaction.options.getInteger("page") || 1;
        const data = await ownerApi("GET", `/v1/projects/${cfg.project_id}/keys?page=${page}&limit=10`, cfg.api_key);
        if (!data.success) return reply(interaction, `❌ ${data.error}`, COL.err);
        if (!data.keys?.length) return reply(interaction, "No keys on this page", COL.warn);
        const lines = data.keys.map(k => {
            const exp = formatExpiry(k);
            const st  = k.active ? "🟢" : "🔴";
            const hw  = k.hwid ? "🔒" : "🔓";
            return `${st}${hw} \`${k.key_string}\` — ${exp} — ${k.total_executions} runs`;
        }).join("\n");
        return replyEmbed(interaction, new EmbedBuilder()
            .setColor(COL.main)
            .setTitle(`🗝️ Keys — Page ${page}`)
            .setDescription(lines));
    }

    // ── /stats ────────────────────────────────────────────────────────────────
    if (commandName === "stats") {
        if (!isManager(member, cfg)) return reply(interaction, "❌ No permission", COL.err);
        const data = await ownerApi("GET", "/v1/stats", cfg.api_key);
        if (!data.success) return reply(interaction, `❌ ${data.error}`, COL.err);
        // Count active vs expired keys
        const { data: allKeys } = await sb.from("keys")
            .select("active, expires_at, total_executions")
            .eq("project_id", cfg.project_id);
        const now     = Math.floor(Date.now() / 1000);
        const active  = (allKeys || []).filter(k => k.active && (!k.expires_at || k.expires_at > now)).length;
        const expired = (allKeys || []).filter(k => k.expires_at && k.expires_at <= now).length;
        const revoked = (allKeys || []).filter(k => !k.active).length;
        const totalR  = (allKeys || []).reduce((s, k) => s + (k.total_executions || 0), 0);
        return replyEmbed(interaction, new EmbedBuilder()
            .setColor(COL.main)
            .setTitle("📊 Whitelist Stats")
            .addFields(
                { name: "🟢 Active Keys",     value: String(active),   inline: true },
                { name: "⛔ Expired",          value: String(expired),  inline: true },
                { name: "🔴 Revoked",          value: String(revoked),  inline: true },
                { name: "🏃 Total Executions", value: String(totalR).padStart(1, "0"), inline: true },
                { name: "📦 Obfs Used",        value: String(data.obfs_used || 0), inline: true },
                { name: "💎 Plan",             value: `\`${data.plan || "starter"}\``, inline: true }
            ).setTimestamp());
    }

    // ── /announce ─────────────────────────────────────────────────────────────
    if (commandName === "announce") {
        if (!isManager(member, cfg)) return reply(interaction, "❌ No permission", COL.err);
        const msg = interaction.options.getString("message");
        // DM all active users
        const { data: keys } = await sb.from("keys")
            .select("discord_id").eq("project_id", cfg.project_id).eq("active", true).not("discord_id", "is", null);
        let sent = 0;
        for (const k of keys || []) {
            try {
                const user = await client.users.fetch(k.discord_id);
                await user.send({ embeds: [new EmbedBuilder()
                    .setColor(COL.warn).setTitle("📢 Script Update")
                    .setDescription(msg)
                    .setFooter({ text: cfg.project_name || "Dragon Whitelist" })
                    .setTimestamp()] });
                sent++;
            } catch {}
            await new Promise(r => setTimeout(r, 200)); // rate limit friendly
        }
        return reply(interaction, `✅ Announced to ${sent}/${keys?.length || 0} users`, COL.ok);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// BUTTON HANDLER (control panel buttons)
// ─────────────────────────────────────────────────────────────────────────────
async function handleButton(interaction) {
    const { customId, guildId, user } = interaction;
    const cfg = await getCfg(guildId);

    // ── Redeem Key button → show modal ────────────────────────────────────────
    if (customId === "panel_redeem") {
        const modal = new ModalBuilder()
            .setCustomId("modal_redeem")
            .setTitle("Redeem Your Key");
        const input = new TextInputBuilder()
            .setCustomId("key_input")
            .setLabel("Enter your key")
            .setPlaceholder("DRAG-XXXXXX-XXXXXX-XXXXXX")
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMinLength(10)
            .setMaxLength(60);
        modal.addComponents(new ActionRowBuilder().addComponents(input));
        return interaction.showModal(modal);
    }

    // ── Get Script button ─────────────────────────────────────────────────────
    if (customId === "panel_script") {
        await interaction.deferReply({ ephemeral: true });
        const info = await internalGet("/internal/keyinfo", { discord_id: user.id });
        if (!info.keys?.length)
            return reply(interaction, "❌ You don't have a key. Use **Redeem Key** or ask a manager to whitelist you.", COL.err);
        const k = info.keys[0];
        if (!k.active) return reply(interaction, "❌ Your key has been revoked. Contact support.", COL.err);
        const loader = `script_key="${k.key_string}"; loadstring(game:HttpGet("${BASE}/v1/auth?key="..script_key.."&hwid="..game:GetService("RbxAnalyticsService"):GetClientId()))()`;
        try {
            await user.send({ embeds: [new EmbedBuilder()
                .setColor(COL.main)
                .setTitle("📋 Your Script Loader")
                .setDescription("Copy the loader below and execute it in your Roblox executor.")
                .addFields(
                    { name: "Loader", value: `\`\`\`lua\n${loader}\n\`\`\`` },
                    { name: "Expires", value: formatExpiry(k), inline: true },
                    { name: "Total Runs", value: String(k.total_executions || 0), inline: true }
                ).setFooter({ text: "Keep this private — your HWID locks on first run" })] });
            return reply(interaction, "✅ Script loader sent to your DMs!", COL.ok);
        } catch {
            return reply(interaction, "❌ Couldn't DM you. Enable **Allow DMs from server members** in your privacy settings.", COL.err);
        }
    }

    // ── Get Role button ───────────────────────────────────────────────────────
    if (customId === "panel_role") {
        await interaction.deferReply({ ephemeral: true });
        if (!cfg?.buyer_role_id) return reply(interaction, "❌ No buyer role configured", COL.err);
        const info = await internalGet("/internal/keyinfo", { discord_id: user.id });
        if (!info.keys?.length) return reply(interaction, "❌ No active key found for your account. Redeem a key first.", COL.err);
        const k = info.keys[0];
        if (!k.active || (k.expires_at && k.expires_at <= Math.floor(Date.now() / 1000)))
            return reply(interaction, "❌ Your key is expired or revoked.", COL.err);
        try {
            const member = await interaction.guild.members.fetch(user.id);
            if (member.roles.cache.has(cfg.buyer_role_id))
                return reply(interaction, "✅ You already have the buyer role!", COL.ok);
            await member.roles.add(cfg.buyer_role_id);
            return reply(interaction, `✅ You've been given <@&${cfg.buyer_role_id}>!`, COL.ok);
        } catch (e) {
            return reply(interaction, "❌ Failed to assign role — make sure the bot has **Manage Roles** permission above the buyer role.", COL.err);
        }
    }

    // ── Reset HWID button ─────────────────────────────────────────────────────
    if (customId === "panel_hwid") {
        await interaction.deferReply({ ephemeral: true });
        const info = await internalGet("/internal/keyinfo", { discord_id: user.id });
        if (!info.keys?.length) return reply(interaction, "❌ No key found for your account.", COL.err);
        const k = info.keys[0];
        // Check cooldown
        const { data: cfgRow } = await sb.from("bot_configs").select("hwid_reset_cooldown").eq("guild_id", guildId).single();
        const cooldownHrs = cfgRow?.hwid_reset_cooldown || 0;
        if (cooldownHrs > 0 && k.last_hwid_reset) {
            const lastReset = new Date(k.last_hwid_reset).getTime();
            const cooldownMs = cooldownHrs * 3600000;
            if (Date.now() - lastReset < cooldownMs) {
                const secsLeft = Math.ceil((lastReset + cooldownMs - Date.now()) / 1000);
                const hoursLeft = Math.floor(secsLeft / 3600);
                return reply(interaction, `⏳ HWID reset on cooldown — ${hoursLeft}h ${Math.floor((secsLeft % 3600)/60)}m remaining.`, COL.warn);
            }
        }
        await sb.from("keys").update({ hwid: null, last_hwid_reset: new Date().toISOString() }).eq("key_string", k.key_string);
        return replyEmbed(interaction, new EmbedBuilder()
            .setColor(COL.ok).setTitle("🔓 HWID Reset")
            .setDescription("Your HWID has been cleared. Run the script again to lock your new HWID."));
    }

    // ── Stats button ──────────────────────────────────────────────────────────
    if (customId === "panel_stats") {
        await interaction.deferReply({ ephemeral: true });
        const info = await internalGet("/internal/keyinfo", { discord_id: user.id });
        if (!info.keys?.length) return reply(interaction, "❌ No key found. Redeem a key first.", COL.err);
        const k = info.keys[0];
        return replyEmbed(interaction, new EmbedBuilder()
            .setColor(COL.main).setTitle("📊 Your Stats")
            .addFields(
                { name: "Status",     value: k.active ? "✅ Active" : "❌ Revoked",          inline: true },
                { name: "Expires",    value: formatExpiry(k),                                  inline: true },
                { name: "HWID",       value: k.hwid ? "🔒 Locked" : "🔓 Not locked",          inline: true },
                { name: "Total Runs", value: String(k.total_executions || 0),                  inline: true },
                { name: "Last Run",   value: k.last_exec ? `<t:${Math.floor(new Date(k.last_exec).getTime()/1000)}:R>` : "Never", inline: true },
                { name: "Key",        value: `\`${k.key_string.slice(0, 12)}...\``,            inline: true }
            ).setFooter({ text: cfg?.project_name || "Dragon Whitelist" }).setTimestamp());
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MODAL HANDLER
// ─────────────────────────────────────────────────────────────────────────────
async function handleModal(interaction) {
    const { customId, guildId, user } = interaction;
    const cfg = await getCfg(guildId);

    // ── Redeem key modal ──────────────────────────────────────────────────────
    if (customId === "modal_redeem") {
        await interaction.deferReply({ ephemeral: true });
        const keyStr = interaction.fields.getTextInputValue("key_input").trim();
        const { data: keyRow } = await sb.from("keys").select("*").eq("key_string", keyStr).single();
        if (!keyRow) return reply(interaction, "❌ Invalid key — double-check and try again.", COL.err);
        if (!keyRow.active) return reply(interaction, "❌ This key has been revoked.", COL.err);
        if (keyRow.expires_at && keyRow.expires_at <= Math.floor(Date.now() / 1000))
            return reply(interaction, "❌ This key has expired.", COL.err);
        if (keyRow.discord_id && keyRow.discord_id !== user.id)
            return reply(interaction, "❌ This key is already claimed by another account.", COL.err);
        // Link discord_id
        if (!keyRow.discord_id)
            await sb.from("keys").update({ discord_id: user.id }).eq("key_string", keyStr);
        // Give buyer role
        try {
            if (cfg?.buyer_role_id) {
                const gm = await interaction.guild.members.fetch(user.id);
                await gm.roles.add(cfg.buyer_role_id);
            }
        } catch {}
        return replyEmbed(interaction, new EmbedBuilder()
            .setColor(COL.ok).setTitle("✅ Key Redeemed!")
            .setDescription(`Your key has been linked to your Discord account.\n\nUse **Get Script** to get your loader, or **Get Role** to get your buyer role.`)
            .addFields(
                { name: "Key",     value: `\`${keyStr}\``, inline: false },
                { name: "Expires", value: formatExpiry(keyRow), inline: true }
            ).setFooter({ text: "Do NOT share your key" }));
    }
}

// ── Reply helpers ─────────────────────────────────────────────────────────────
async function reply(interaction, text, color = COL.main) {
    return interaction.editReply({ embeds: [new EmbedBuilder().setColor(color).setDescription(text)] });
}
async function replyEmbed(interaction, embed) {
    return interaction.editReply({ embeds: [embed] });
}

// ── Ready ─────────────────────────────────────────────────────────────────────
client.once("ready", async () => {
    console.log(`[Bot] Ready as ${client.user.tag}`);
    client.user.setActivity("Dragon Whitelist", { type: ActivityType.Watching });
    await registerCommands();
});

client.login(process.env.DISCORD_BOT_TOKEN);
